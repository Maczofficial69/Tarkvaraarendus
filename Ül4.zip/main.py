import pygame, sys, random, time # Impordib vajalikud asjad
pygame.init() #initsialiseerib pygamei
screen = pygame.display.set_mode((640, 480)) # ekraani suurus
pygame.display.set_caption("Animeerimine") # Seab ekraani pealkirja
clock = pygame.time.Clock() # Loob objekti clock

start_time = time.time() # Saab praeguse aja
Score = 0 # intisialiseerib skoori

bg = pygame.image.load("bg_rally.jpg") #laeb tausta
pygame.display.flip()

f1_blue = pygame.image.load("f1_blue.png") #laeb sinise f1 pildi
f1_blue = pygame.transform.rotate(f1_blue, 180) #keerab autopildi õiget pidi

f2_blue = pygame.image.load("f1_blue.png") #Laeb auto pildi
f2_blue = pygame.transform.rotate(f2_blue, 180) #keerab autopildi õiget pidi

f1_red = pygame.image.load("f1_red.png") # Laeb autopildi

# Tausta liikumine
class background():
    def __init__(self):
        self.bgimage = pygame.image.load('bg_rally.jpg')
        self.rectBGimg = self.bgimage.get_rect()

        self.bgY1 = 0
        self.bgX1 = 0

        self.bgY2 = self.rectBGimg.height
        self.bgX2 = 0

        self.movingUpSpeed = 5

    def update(self):
        self.bgY1 -= self.movingUpSpeed
        self.bgY2 -= self.movingUpSpeed
        if self.bgY1 <= -self.rectBGimg.height:
            self.bgY1 = self.rectBGimg.height
        if self.bgY2 <= -self.rectBGimg.height:
            self.bgY2 = self.rectBGimg.height

    def render(self):
        screen.blit(self.bgimage, (self.bgX1, self.bgY1))
        screen.blit(self.bgimage, (self.bgX2, self.bgY2))

BspeedY = 3 # Auto kiirus

BposY = random.randint(0, 100) # Autode positsioon
B2posY = random.randint(0, 100) # Auto positsioon
B3posY = (0,0)
B3posX = (0,0)
RposX, RposY = 298, 390 # initsialiseerib auto positsiooni
R2posX, R2posY = 0, 0
R3speedY = 0
RspeedY = 0
R2speedX = 0# initsialiseerib auto kiiruse
gameover = False # initsialiseerib game overi
BposX = random.randint(450, 460)  # initsialiseerib auto positsiooni
B2posX = random.randint(450, 460)


while not gameover: # Niikaua kui mäng pole läbi on loop
    # fps
    clock.tick(60) # seab fpsi
    # quitib gamei kui mäng on kinni
    for event in pygame.event.get(): # event handling loop
        if event.type == pygame.QUIT: # Kui window kinni
            sys.exit() # quitib mangu


    # pildi lisamine ekraanile
    screen.blit(bg, (0, 0)) # renderdab backgroundi
    screen.blit(f1_blue, (BposX, BposY)) # renderdab auto pildi
    screen.blit(f2_blue, (B2posX, B2posY)) # renderdab auto pildi
    BposY += BspeedY # move car
    screen.blit(f1_red, (RposX, RposY)) # renderdab auto pildi
    RposY += RspeedY # liigutab autot
    R2posY += R2speedX
    screen.blit(pygame.font.Font(None, 30).render(f"Skoor: {Score}", True, [255, 255, 255]), [10, 460]) # score

    if BposY >= 480: # Kui auto on pildist valjas
        BposY = -120 # resetib auto asukoha
        Score += 1 # tõstab skoori
        BposX = random.randint(130, 280) # auto asukoha initsialiseerimine


    #Auto liigutamine nooltega
    keys = pygame.key.get_pressed() # otsib vajutatud nuppe
    if keys[pygame.K_UP]: # liigutab autot ülesse
        RposY -= 5 # liigutab autot ülesse
    if keys[pygame.K_DOWN]: # liigutab autot alla
        RposY += 5 # liigutab autot alla
    if keys[pygame.K_LEFT]: # liigutab autot vasakule
        RposX -= 5 # liigutab autot vasakule
    if keys[pygame.K_RIGHT]: # liigutab autot paremale
        RposX += 5 # liigutab autot paremale

    if B2posY >= 480: # kui auto on ekraanist valjas
        B2posY = -120 # resetib auto asukoha
        Score += 1 # tõstab skoori
        B2posX = random.randint(300, 480) # initsialiseerib auto asukoha

    if RposY >= 480: # kui auto on ekraanist valjas
        RposY = -120 # resetib auto asukoha

        # lõpetab mängu kui sinine auto läheb punase vastu
    if B2posY <= RposY + 58 and B2posY >= RposY - 58: # kui sinine auto on samas y positsoonis kui punane
        if B2posX <= RposX + 55 and B2posX >= RposX - 55: # kui sinine auto on samas x positsoonis kui punane
            gameover = True # on gameover

    if BposY <= RposY + 58 and BposY >= RposY - 58: # lõpetab mängu kui sinine auto läheb punase vastu
        if BposX <= RposX + 55 and BposX >= RposX - 55: # lõpetab mängu kui sinine auto läheb punase vastu
            gameover = True # lõpetab mangu
    # tõstab kiirust iga 10 sek tagant
    if time.time() % 10 == 0: #
        BspeedY += 1 # tõstab kiirust

    # näitab aega ekraanil

    screen.blit(pygame.font.Font(None, 20).render(f"Aega kulunud: {int(time.time() - start_time)}", True, [255, 255, 255]), [519, 40]) # show time elapsed


    # näitab kiirust ekraanil
    screen.blit(pygame.font.Font(None, 30).render(f"Kiirus: {BspeedY}", True, [255, 255, 255]), [10, 10]) # show current speed on top left as text


    pygame.display.flip() # updateb ekraani
gameoverbg= pygame.image.load("gameover.png") # laeb gameover pildi
while True: # loopib gameoverit

    if gameover == True: # kui gameover on true
        screen.blit(gameoverbg, (0, 0)) # siis naitab gameover pilti
        screen.blit(pygame.font.Font(None, 50).render(f"Skoor: {Score}", True, [255, 255, 255]), [250, 400]) # näitab skoori
        pygame.display.flip() # updateb ekraani
    for event in pygame.event.get(): # checkib evente
        if event.type == pygame.QUIT: # väljub mangust kui ekraan kinni
            sys.exit() # väljub mangust kui ekraan kinni