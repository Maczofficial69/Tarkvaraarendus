#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pygame
from player import Player
from enemies import *
import time
import sys
import tkinter
from tkinter import messagebox
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 576
pygame.init()
# Värvide RGB koodid
BLACK = (0,0,0)
WHITE = (255,255,255)
BLUE = (0,0,255)
RED = (255,0,0)


clock = pygame.time.Clock()
start_time = time.time()



class Game(object):
    def __init__(self):
        self.font = pygame.font.Font(None,40)
        self.about = False
        self.game_over = True
        # Loob skoori
        self.score = 0
        # Loob fondi mida kujutatakse ekraanil
        self.font = pygame.font.Font(None,35)
        # Loob start menüü
        self.menu = Menu(("Start","Kirjeldus","Välju"),font_color = WHITE,font_size=60)
        # Loob mängija
        self.player = Player(32,128,"player.png")
        # Loob blockid kuhu mängija saab liikuda
        self.horizontal_blocks = pygame.sprite.Group()
        self.vertical_blocks = pygame.sprite.Group()
        # Loob punktid ekraanil millega saab skoori
        self.dots_group = pygame.sprite.Group()
        # Set the enviroment:
        for i,row in enumerate(enviroment()):
            for j,item in enumerate(row):
                if item == 1:
                    self.horizontal_blocks.add(Block(j*32+8,i*32+8,BLACK,16,16))
                elif item == 2:
                    self.vertical_blocks.add(Block(j*32+8,i*32+8,BLACK,16,16))
        # Loob ghostid ekraanil
        self.enemies = pygame.sprite.Group()
        self.enemies.add(Slime(288,96,0,2))
        self.enemies.add(Slime(288,320,0,-2))
        self.enemies.add(Slime(544,128,0,2))
        self.enemies.add(Slime(32,224,0,2))
        self.enemies.add(Slime(160,64,2,0))
        self.enemies.add(Slime(448,64,-2,0))
        self.enemies.add(Slime(640,448,2,0))
        self.enemies.add(Slime(448,320,2,0))
        # Lisab punktid mängu sisse
        for i, row in enumerate(enviroment()):
            for j, item in enumerate(row):
                if item != 0:
                    self.dots_group.add(Ellipse(j*32+12,i*32+12,WHITE,8,8))

        # Loob mängu heliefektid
        self.pacman_sound = pygame.mixer.Sound("pacman_sound.ogg")
        self.game_over_sound = pygame.mixer.Sound("game_over_sound.ogg")





    def process_events(self):
        for event in pygame.event.get(): # User did something
            if event.type == pygame.QUIT: # Kui kasutaja paneb mängu kinni
                return True
            self.menu.event_handler(event)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if self.game_over and not self.about:
                        if self.menu.state == 0:
                            # Start nupp menüül
                            self.__init__()
                            self.game_over = False
                        elif self.menu.state == 1:
                            # about nupp menüül
                            self.about = True
                        elif self.menu.state == 2:
                            # --- EXIT -------
                            # Kui kasutaja vajutas exit nuppu
                            return True
# Loob kasutajale liikumis nupud
                elif event.key == pygame.K_RIGHT:
                    self.player.move_right()

                elif event.key == pygame.K_LEFT:
                    self.player.move_left()

                elif event.key == pygame.K_UP:
                    self.player.move_up()

                elif event.key == pygame.K_DOWN:
                    self.player.move_down()

#Mäng läheb pausile kui vajutatakse escape'i
                elif event.key == pygame.K_ESCAPE:
                    self.game_over = True
                    self.about = False
# Realiseerib mängu nupud
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_RIGHT:
                    self.player.stop_move_right()
                elif event.key == pygame.K_LEFT:
                    self.player.stop_move_left()
                elif event.key == pygame.K_UP:
                    self.player.stop_move_up()
                elif event.key == pygame.K_DOWN:
                    self.player.stop_move_down()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.player.explosion = True
                    
        return False

    def run_logic(self):
        if not self.game_over:
            self.player.update(self.horizontal_blocks,self.vertical_blocks)
            block_hit_list = pygame.sprite.spritecollide(self.player,self.dots_group,True)
            # Kui mängija läheb punkti vastu
            if len(block_hit_list) > 0:
                # See mängib sound effekte õigel ajal
                self.pacman_sound.play()
                self.score += 1
            block_hit_list = pygame.sprite.spritecollide(self.player,self.enemies,True)
            if len(block_hit_list) > 0:
                self.player.explosion = True
                self.game_over_sound.play()
            self.game_over = self.player.game_over
            self.enemies.update(self.horizontal_blocks,self.vertical_blocks)

    def display_frame(self,screen):
        screen.fill(BLACK)
        # Tausta värv
        if self.game_over:
            if self.about:
                self.display_message(screen,"SEE ON PACMAN MEES")#Kirjeldus ekraanil kiri
            else:
                self.menu.display_frame(screen)
        else:
            # Joonistab mängu
            self.horizontal_blocks.draw(screen)
            self.vertical_blocks.draw(screen)
            draw_enviroment(screen)
            self.dots_group.draw(screen)
            self.enemies.draw(screen)
            screen.blit(self.player.image,self.player.rect)
            screen.blit(pygame.font.Font(None, 50).render(f"Aeg: {int(time.time() - start_time)}", True,
                                                        [255, 255, 255]),
                      [600, 10])
            # renderdab teksti
            text = self.font.render("Score: " + str(self.score) + str("/200"),True,RED)
            # paneb teksti ekraanile
            screen.blit(text,[120,20])

        # updateb ekraani.
        pygame.display.flip()


# kujutab sõnumeid ekraanil
    def display_message(self,screen,message,color=(255,0,0)):
        label = self.font.render(message,True,color)
        # võtab laiuse ja pikkuse ekraanil
        width = label.get_width()
        height = label.get_height()
        # Saab labeli positsiooni ekraanil
        posX = (SCREEN_WIDTH /2) - (width /2)
        posY = (SCREEN_HEIGHT /2) - (height /2)
        # Joonistab labeli ekraanile
        screen.blit(label,(posX,posY))


def game_paused():
    pass

# Menüü font ja teksti värv
class Menu(object):
    state = 0
    def __init__(self,items,font_color=(0,0,0),select_color=(255,0,0),ttf_font=None,font_size=25):
        self.font_color = font_color
        self.select_color = select_color
        self.items = items
        self.font = pygame.font.Font(ttf_font,font_size)
     # Kujutab teksti ekraanil
    def display_frame(self,screen):
        for index, item in enumerate(self.items):
            if self.state == index:
                label = self.font.render(item,True,self.select_color)
            else:
                label = self.font.render(item,True,self.font_color)
            
            width = label.get_width()
            height = label.get_height()
            
            posX = (SCREEN_WIDTH /2) - (width /2)
            # t_h: total height of text block
            t_h = len(self.items) * height
            posY = (SCREEN_HEIGHT /2) - (t_h /2) + (index * height)
            
            screen.blit(label,(posX,posY))

     # Realiseerib liikumist ekraanil
    def event_handler(self,event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if self.state > 0:
                    self.state -= 1
            elif event.key == pygame.K_DOWN:
                if self.state < len(self.items) -1:
                    self.state += 1

        if event.type == pygame.K_p:
            pause_xy = event.pos
            if pause_xy[0] > (SCREEN_WIDTH - 50) and pause_xy[0] < SCREEN_WIDTH:
                if pause_xy[1] > 0 and pause_xy[1] < 50:
                    game_paused()

        
