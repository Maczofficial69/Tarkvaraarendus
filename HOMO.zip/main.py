import pygame
from game import Game

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 576

clock = pygame.time.Clock()
FPS = 15
FPS = int(input("Sisesta mängu raskus 10-120: "))

def main():
    # Initialize all imported pygame modules
    pygame.init()
    pygame.mixer.music.load('pacman.mp3')

    pygame.mixer.music.play(-1)
    # Set the width and height of the screen [width, height]
    screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
    # Set the current window caption
    pygame.display.set_caption("PACMAN - Merili, Remo")
    #Loop until the user clicks the close button.
    done = False
    # Used to manage how fast the screen updates
    clock = pygame.time.Clock()
    # Create a game object
    game = Game()
    # -------- Main Program Loop -----------
    while not done:
        # --- Process events (keystrokes, mouse clicks, etc)
        done = game.process_events()
        # --- Game logic should go here
        game.run_logic()
        # --- Draw the current frame
        game.display_frame(screen)
        # --- Limit to 30 frames per second
        clock.tick(FPS)
        #tkMessageBox.showinfo("GAME OVER!","Final Score = "+(str)(GAME.score))
    # Close the window and quit.
    # If you forget this line, the program will 'hang'
    # on exit if running from IDLE.
    pygame.quit()
if __name__ == '__main__':
    main()
