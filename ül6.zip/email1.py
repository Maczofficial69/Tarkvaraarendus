import smtplib

sender_email = "sauksremo@gmail.com" # saatja email
rec_email = "remo.sauks@vikk.ee" # saaja email
password = input(str("Palun sisesta oma parool : ")) # parooli input
message = "Jou, saatsin selle python'iga" # emaili sõnum

server = smtplib.SMTP('smtp.gmail.com', 587) # server
server.starttls()
print("Login Success") # prindib login success
server.sendmail(sender_email, rec_email, message)# võtab saatja ja saaja emaili ning sõnumi
print("Email has been sent to", rec_email) # prindib email on saadetud ja saatja emaili