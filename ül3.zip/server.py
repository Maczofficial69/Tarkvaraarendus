import socket # impordib socketi

s = socket.socket() #lühend socket.socketile
host = socket.gethostname () # lühend socket.gethostname'le
port = 8080 # tähistab porti
s.bind ((host,port)) #bindib socket hostile ja portile
s.listen(1) #Kuulab sissetulevaid ühendusi
print(host) # prindib hosti nime
print("Waiting for any incoming connections...") # Prindib teksti
conn, addr = s.accept () # aktsepteerib ühenduse
print(addr, "Has connected to the server") # prindib teksti

filename = input(str("Please enter the filename of the file: ")) # Saad inputiga faili nime sisestada
file = open(filename , 'rb') #võtab faili ja avab rbs
file_data = file.read(1024)#Loeb faili sisu
conn.send(file_data)# saadab faili sisu
print("Data has been transmitted successfully")# prindib teksti

