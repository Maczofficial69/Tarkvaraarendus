import socket # impordib
s = socket.socket() # lühend socket.socketile
host = input(str("Please enter the host address of the sender: ")) #Pead sistema server.py's tulnud hosti nime
port = 8080 # seab pordi
s.connect((host,port)) # ühendab kui host on õige ja port
print("Connected...") # prindib teksti

filename = input(str("Please enter the filename for the incoming file")) # Pead sisestama faili nime mis server.py's sisestati
file = open(filename, 'wb') # openib file wb's
file_data = s.recv(1024) # Saab faili sisu kätte
file.write(file_data)# kirjutab faili sisu
file.close () # closeb faili
print("File has been received successfully") # prindib teksti
